/*---------------------------------------------------------------------------------*
* String prototype
*---------------------------------------------------------------------------------*/
//-----------------------------------------------------------------------------
// ������ ��, �� ���� ����
// @return : String
//-----------------------------------------------------------------------------
String.prototype.trim = function() {
    return this.replace(/(^\s*)|(\s*$)/gi, "");
}
//-----------------------------------------------------------------------------
// ������ �� ���� ����
// @return : String
//-----------------------------------------------------------------------------
String.prototype.ltrim = function() {
return this.replace(/(^s*)/, "");
}
//-----------------------------------------------------------------------------
// ������ �� ���� ����
// @return : String
//-----------------------------------------------------------------------------
String.prototype.rtrim = function() {
return this.replace(/(s*$)/, "");
}
//-----------------------------------------------------------------------------
// str1 ���ڿ��� str2���ڿ��� ġȯ�Ѵ�.
// str.replaceAll(�������ڿ�, ġȯ���ڿ�)
// @return : String
//-----------------------------------------------------------------------------
String.prototype.replaceAll = function(str1, str2) {
var temp = "";
if (this.trim() != "" && str1 != str2) {
temp = this.trim();
while (temp.indexOf(str1) > -1) {
temp = temp.replace(str1, str2);
}
}
return temp;
}
//-----------------------------------------------------------------------------
// ���ڿ��� byte ���� ��ȯ
// @return : int
//-----------------------------------------------------------------------------
String.prototype.byte = function() {
var cnt = 0;
for (var i = 0; i < this.length; i++) {
if (this.charCodeAt(i) > 127)
cnt += 2;
else
cnt++;
}
return cnt;
}
//-----------------------------------------------------------------------------
// ���������� ��ȯ
// @return : String
//-----------------------------------------------------------------------------
String.prototype.int = function() {
if(!isNaN(this)) {
return parseInt(this);
}
else {
return null;
}
}
//-----------------------------------------------------------------------------
// ���ڸ� ���� ����
// @return : String
//-----------------------------------------------------------------------------
String.prototype.num = function() {
return this.trim().replace(/[^0-9]/g, "");
}
//-----------------------------------------------------------------------------
// ���ڸ� ���� ����(- ��ȣ ����)
// @return : String
//-----------------------------------------------------------------------------
String.prototype.numSign = function() {
var sign = "";
if ( this.charAt(0) == '-' ) sign = "-";
return sign + this.num();
}

String.prototype.number_format = function() {
        var num = this.trim();
        while((/(-?[0-9]+)([0-9]{3})/).test(num)) {
            num = num.replace((/(-?[0-9]+)([0-9]{3})/), "$1,$2");
        }
        return num;
    }
//-----------------------------------------------------------------------------
// ���ڿ� 3�ڸ����� , �� �� ��ȯ
// @return : String
//-----------------------------------------------------------------------------
String.prototype.money = function() {
var num = this.trim();
while((/(-?[0-9]+)([0-9]{3})/).test(num)) {
num = num.replace((/(-?[0-9]+)([0-9]{3})/), "$1,$2");
}
return num;
}
//-----------------------------------------------------------------------------
// ������ �ڸ���(cnt)�� �µ��� ��ȯ
// @return : String
//-----------------------------------------------------------------------------
String.prototype.digits = function(cnt) {
var digit = "";
if (this.length < cnt) {
for(var i = 0; i < cnt - this.length; i++) {
digit += "0";
}
}
return digit + this;
}
//-----------------------------------------------------------------------------
// " -> &#34; ' -> &#39;�� �ٲپ ��ȯ
// @return : String
//-----------------------------------------------------------------------------
String.prototype.quota = function() {
return this.replace(/"/g, "&#34;").replace(/'/g, "&#39;");
}
//-----------------------------------------------------------------------------
// ���� Ȯ���ڸ� ��������
// @return : String
//-----------------------------------------------------------------------------
String.prototype.ext = function() {
return (this.indexOf(".") < 0) ? "" : this.substring(this.lastIndexOf(".") + 1, this.length);
}
//-----------------------------------------------------------------------------
// URL���� �Ķ���� ������ ������ url ���
// @return : String
//-----------------------------------------------------------------------------
String.prototype.uri = function() {
var arr = this.split("?");
arr = arr[0].split("#");
return arr[0];
}
/*---------------------------------------------------------------------------------*
* ���� üũ �Լ���
*---------------------------------------------------------------------------------*/
//-----------------------------------------------------------------------------
// ���ԽĿ� ���̴� Ư�����ڸ� ã�Ƽ� �̽������� �Ѵ�.
// @return : String
//-----------------------------------------------------------------------------
String.prototype.meta = function() {
var str = this;
var pattern = /([$()*+.[]?\^{}|]{1})/;
var result = ""
for(var i = 0; i < str.length; i++) {
if((/([$()*+.[]?\^{}|]{1})/).test(str.charAt(i))) {
result += str.charAt(i).replace((/([$()*+.[]?\^{}|]{1})/), "\$1");
}
else {
result += str.charAt(i);
}
}
return result;
}
//-----------------------------------------------------------------------------
// ���ԽĿ� ���̴� Ư�����ڸ� ã�Ƽ� �̽������� �Ѵ�.
// @return : String
//-----------------------------------------------------------------------------
String.prototype.remove = function(pattern) {
return (pattern == null) ? this : eval("this.replace(/[" + pattern.meta() + "]/g, '')");
}
//-----------------------------------------------------------------------------
// �ּ� �ִ� �������� ����
// str.isLength(min [,max])
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isLength = function() {
var min = arguments[0];
var max = arguments[1] ? arguments[1] : null;
var success = true;
if(this.length < min) {
success = false;
}
if(max && this.length > max) {
success = false;
}
return success;
}
//-----------------------------------------------------------------------------
// �ּ� �ִ� ����Ʈ���� ����
// str.isByteLength(min [,max])
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isByteLength = function() {
var min = arguments[0];
var max = arguments[1] ? arguments[1] : null;
var success = true;
if(this.byte() < min) {
success = false;
}
if(max && this.byte() > max) {
success = false;
}
return success;
}
//-----------------------------------------------------------------------------
// �����̳� ������ Ȯ��
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isBlank = function() {
var str = this.trim();
for(var i = 0; i < str.length; i++) {
if ((str.charAt(i) != "t") && (str.charAt(i) != "n") && (str.charAt(i)!="r")) {
return false;
}
}
return true;
}
//-----------------------------------------------------------------------------
// ���ڷ� �����Ǿ� �ִ��� ����
// arguments[0] : ����� ���ڼ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isNum = function() {
return (/^[0-9]+$/).test(this.remove(arguments[0])) ? true : false;
}
//-----------------------------------------------------------------------------
// ��� ��� - arguments[0] : �߰� ����� ���ڵ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isEng = function() {
return (/^[a-zA-Z]+$/).test(this.remove(arguments[0])) ? true : false;
}
//-----------------------------------------------------------------------------
// ���ڿ� ��� ��� - arguments[0] : �߰� ����� ���ڵ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isEngNum = function() {
return (/^[0-9a-zA-Z]+$/).test(this.remove(arguments[0])) ? true : false;
}
//-----------------------------------------------------------------------------
// ���ڿ� ��� ��� - arguments[0] : �߰� ����� ���ڵ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isNumEng = function() {
return this.isEngNum(arguments[0]);
}
//-----------------------------------------------------------------------------
// ���̵� üũ ����� ���ڸ� üũ ù���ڴ� ����� ���� - arguments[0] : �߰� ����� ���ڵ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isUserid = function() {
return (/^[a-zA-z]{1}[0-9a-zA-Z]+$/).test(this.remove(arguments[0])) ? true : false;
}
//-----------------------------------------------------------------------------
// �ѱ� üũ - arguments[0] : �߰� ����� ���ڵ�
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isKor = function() {
return (/^[��-�R]+$/).test(this.remove(arguments[0])) ? true : false;
}
//-----------------------------------------------------------------------------
// �ֹι�ȣ üũ - arguments[0] : �ֹι�ȣ ������
// XXXXXX-XXXXXXX
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isJumin = function() {
var arg = arguments[0] ? arguments[0] : "";
var jumin = eval("this.match(/[0-9]{2}[01]{1}[0-9]{1}[0123]{1}[0-9]{1}" + arg + "[1234]{1}[0-9]{6}$/)");
if(jumin == null) {
return false;
}
else {
jumin = jumin.toString().num().toString();
}
// ������� üũ
var birthYY = (parseInt(jumin.charAt(6)) == (1 ||2)) ? "19" : "20";
birthYY += jumin.substr(0, 2);
var birthMM = jumin.substr(2, 2) - 1;
var birthDD = jumin.substr(4, 2);
var birthDay = new Date(birthYY, birthMM, birthDD);
if(birthDay.getYear() % 100 != jumin.substr(0,2) || birthDay.getMonth() != birthMM || birthDay.getDate() != birthDD) {
return false;
}
var sum = 0;
var num = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5]
var last = parseInt(jumin.charAt(12));
for(var i = 0; i < 12; i++) {
sum += parseInt(jumin.charAt(i)) * num[i];
}
return ((11 - sum % 11) % 10 == last) ? true : false;
}
//-----------------------------------------------------------------------------
// �ܱ��� ��Ϲ�ȣ üũ - arguments[0] : ��Ϲ�ȣ ������
// XXXXXX-XXXXXXX
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isForeign = function() {
var arg = arguments[0] ? arguments[0] : "";
var jumin = eval("this.match(/[0-9]{2}[01]{1}[0-9]{1}[0123]{1}[0-9]{1}" + arg + "[5678]{1}[0-9]{1}[02468]{1}[0-9]{2}[6789]{1}[0-9]{1}$/)");
if(jumin == null) {
return false;
}
else {
jumin = jumin.toString().num().toString();
}
// ������� üũ
var birthYY = (parseInt(jumin.charAt(6)) == (5 || 6)) ? "19" : "20";
birthYY += jumin.substr(0, 2);
var birthMM = jumin.substr(2, 2) - 1;
var birthDD = jumin.substr(4, 2);
var birthDay = new Date(birthYY, birthMM, birthDD);
if(birthDay.getYear() % 100 != jumin.substr(0,2) || birthDay.getMonth() != birthMM || birthDay.getDate() != birthDD) {
return false;
}
if((parseInt(jumin.charAt(7)) * 10 + parseInt(jumin.charAt(8))) % 2 != 0) {
return false;
}
var sum = 0;
var num = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5]
var last = parseInt(jumin.charAt(12));
for(var i = 0; i < 12; i++) {
sum += parseInt(jumin.charAt(i)) * num[i];
}
return (((11 - sum % 11) % 10) + 2 == last) ? true : false;
}
//-----------------------------------------------------------------------------
// ����ڹ�ȣ üũ - arguments[0] : ��Ϲ�ȣ ������
// XX-XXX-XXXXX
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isBiznum = function() {
var arg = arguments[0] ? arguments[0] : "";
var biznum = eval("this.match(/[0-9]{3}" + arg + "[0-9]{2}" + arg + "[0-9]{5}$/)");
if(biznum == null) {
return false;
}
else {
biznum = biznum.toString().num().toString();
}
var sum = parseInt(biznum.charAt(0));
var num = [0, 3, 7, 1, 3, 7, 1, 3];
for(var i = 1; i < 8; i++) sum += (parseInt(biznum.charAt(i)) * num[i]) % 10;
sum += Math.floor(parseInt(parseInt(biznum.charAt(8))) * 5 / 10);
sum += (parseInt(biznum.charAt(8)) * 5) % 10 + parseInt(biznum.charAt(9));
return (sum % 10 == 0) ? true : false;
}
//-----------------------------------------------------------------------------
// ���� ��Ϲ�ȣ üũ - arguments[0] : ��Ϲ�ȣ ������
// XXXXXX-XXXXXXX
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isCorpnum = function() {
var arg = arguments[0] ? arguments[0] : "";
var corpnum = eval("this.match(/[0-9]{6}" + arg + "[0-9]{7}$/)");
if(corpnum == null) {
return false;
}
else {
corpnum = corpnum.toString().num().toString();
}
var sum = 0;
var num = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
var last = parseInt(corpnum.charAt(12));
for(var i = 0; i < 12; i++) {
sum += parseInt(corpnum.charAt(i)) * num[i];
}
return ((10 - sum % 10) % 10 == last) ? true : false;
}
//-----------------------------------------------------------------------------
// �̸����� ��ȿ���� üũ
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isEmail = function() {
	return (/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi).test(this.trim()) 
	//return (/w+([-+.]w+)*@w+([-.]w+)*.[a-zA-Z]{2,4}$/).test(this.trim());
}
//-----------------------------------------------------------------------------
// ��ȭ��ȣ üũ - arguments[0] : ��ȭ��ȣ ������
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isPhone = function() {
var arg = arguments[0] ? arguments[0] : "";
return eval("(/(02|0[3-9]{1}[0-9]{1})" + arg + "[1-9]{1}[0-9]{2,3}" + arg + "[0-9]{4}$/).test(this)");
}
//-----------------------------------------------------------------------------
// �ڵ�����ȣ üũ - arguments[0] : �ڵ��� ������
// @return : boolean
//-----------------------------------------------------------------------------
String.prototype.isMobile = function() {
var arg = arguments[0] ? arguments[0] : "";
return eval("(/01[016789]" + arg + "[1-9]{1}[0-9]{2,3}" + arg + "[0-9]{4}$/).test(this)");
}						


//<![CDATA[
function initMoving(target, position, topLimit, btmLimit) {
	if (!target)
		return false;

	var obj = target;
	obj.initTop = position;
	obj.topLimit = topLimit;
	obj.bottomLimit = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight) - btmLimit - obj.offsetHeight;

	obj.style.position = "absolute";
	obj.top = obj.initTop;
	obj.left = obj.initLeft;

	if (typeof(window.pageYOffset) == "number") {	//WebKit
		obj.getTop = function() {
			return window.pageYOffset;
		}
	} else if (typeof(document.documentElement.scrollTop) == "number") {
		obj.getTop = function() {
			return Math.max(document.documentElement.scrollTop, document.body.scrollTop);
		}
	} else {
		obj.getTop = function() {
			return 0;
		}
	}

	if (self.innerHeight) {	//WebKit
		obj.getHeight = function() {
			return self.innerHeight;
		}
	} else if(document.documentElement.clientHeight) {
		obj.getHeight = function() {
			return document.documentElement.clientHeight;
		}
	} else {
		obj.getHeight = function() {
			return 500;
		}
	}

	obj.move = setInterval(function() {
		if (obj.initTop > 0) {
			pos = obj.getTop() + obj.initTop;
		} else {
			pos = obj.getTop() + obj.getHeight() + obj.initTop;
			//pos = obj.getTop() + obj.getHeight() / 2 - 15;
		}

		if (pos > obj.bottomLimit)
			pos = obj.bottomLimit;
		if (pos < obj.topLimit)
			pos = obj.topLimit;

		interval = obj.top - pos;
		obj.top = obj.top - interval / 8;
		obj.style.top = obj.top + "px";
	}, 30)
}

/*******************************************			
				Cookie Set
	*******************************************/
	var Cookie = {
		getCookie : function(name) {
			var Found = 0, start, end, i =0;
			while(i <= document.cookie.length) { 
				start = i;
				end = start + name.length;				
				if(document.cookie.substring(start,end) == name) {					
					Found = 1;
					break;
				}
				i++;
			}
			if(Found == 1) {
				start = end+1;
				end = document.cookie.indexOf(';', start);			
				if(end < start) end= document.cookie.length;
				return document.cookie.substring(start,end)				
			}
			return false
		},
		setCookie : function(name, value, expire) {
			var expire_date = new Date();
			var day = 24 * expire;
			expire_date = new Date(expire_date.getTime() + 60*60*day*1000);
			if(expire == null) document.cookie = name + "=" + escape(value) + "; path=/";
			else	document.cookie = name + "=" + escape(value) + "; expires=" + expire_date.toGMTString() +"; path=/";
		},			
		clearCookie : function(name){
			var expire_date = new Date();
			//���� ��¥�� ��Ű �Ҹ� ��¥�� �����Ѵ�.
			expire_date = new Date(expire_date.getTime() - 60*60*24*1000)
			document.cookie = name + "= " + "; expires=" + expire_date.toGMTString();
		}		
	}

/*���̾����� Ʈ��*/
var db = "";
function trick() {
  if (db != $('input[name=search]').val()) {
      db = $('input[name=search]').val();
      search_script(db);
  } else {
  }
  setTimeout("trick()", 100);
}
/*���̾����� Ʈ�� ��*/


$(document).ready(function(){
	var  suggestBand = {
		pos : 0,
		archive : ''
	};

  if($.browser.opera==true || $.browser.mozilla==true ) {
    $('input[name=findValue]').keypress(function(event){
      trick();
    });
  } 
  else {
    $('input[name=findValue]').keyup(function(event){

	  if(event.keyCode == 40){
		  var sugget_list = $("#search_text li")
			if(sugget_list.length >  suggestBand.pos){ 
				suggestBand.pos = suggestBand.pos+1
				for(var i=0;i <sugget_list.length;i++) {
					if(suggestBand.pos == (i+1)) {
						$(sugget_list[i]).css("background",'#eee')
						//suggestBand.archive = $(sugget_list[i]).text() // Ű���� ����						
						$('input[name=findValue]').val($(sugget_list[i]).text())
					}
					else {
						$(sugget_list[i]).css("background",'#fff')				
					}
				}
		  }
	  }
	  else if(event.keyCode == 38) {
				  var sugget_list = $("#search_text li")
					suggestBand.pos = suggestBand.pos-1
					for(var i=0;i <sugget_list.length;i++) {
							if(suggestBand.pos == (i+1)) {
								$(sugget_list[i]).css("background",'#eee')
								$('input[name=findValue]').val($(sugget_list[i]).text())										
							}
							else {
								$(sugget_list[i]).css("background",'#fff')
							}
					}
	  } 
	  else if(event.keyCode == 13) {
		  //$("#searchForm").submit()
	  }
      else if(event.keyCode !=27){
		 if(!$(this).val()) {		 
			$('#text_div').hide();
		 }
		 else {
			search_script($(this).val());
		 }
		suggestBand.pos = 0
      } 
	  else {
        $('#text_div').hide();
      }
	  return false;
    });	
  }
	
  $("#searchForm").submit(function(){
		return true;
  })

	$('body').mousedown(function(){							
								setTimeout(function(){
									$('#text_div').css("display","none")
								}, 300)							
	})

    var currentPosition = 0;
  var slideWidth = 200;
  var slides = $('.slide');
  var numberOfSlides = slides.length;

  // Remove scrollbar in JS
  $('#slidesContainer').css('overflow', 'hidden');

  // Wrap all .slides with #slideInner div
  slides
	.wrapAll('<div id="slideInner"></div>')
    // Float left to display horizontally, readjust .slides width
	.css({
      'float' : 'left',
      'width' : slideWidth
    });

  // Set #slideInner width equal to total width of all slides
  $('#slideInner').css('width', slideWidth * numberOfSlides);

  // Insert controls in the DOM
  $('#slideshow')
    .prepend('<span class="control" id="leftControl">Clicking moves left</span>')
    .append('<span class="control" id="rightControl">Clicking moves right</span>');

  // Hide left arrow control on first load
  manageControls(currentPosition);

  // Create event listeners for .controls clicks
  $('.control')
    .bind('click', function(){
    // Determine new position
	currentPosition = ($(this).attr('id')=='rightControl') ? currentPosition+1 : currentPosition-1;
    
	// Hide / show controls
    manageControls(currentPosition);
    // Move slideInner using margin-left
    $('#slideInner').animate({
      'marginLeft' : slideWidth*(-currentPosition)
    });
  });

  // manageControls: Hides and Shows controls depending on currentPosition
  function manageControls(position){
    // Hide left arrow if position is first slide
	if(position==0){ $('#leftControl').hide() } else{ $('#leftControl').show() }
	// Hide right arrow if position is last slide
    if(position==numberOfSlides-1){ $('#rightControl').hide() } else{ $('#rightControl').show() }
  }	

});


function search_script(keyword) {
  $.post("/rd/application/suggest_search_sever_hangul.php",{
    key : keyword,
	hangul : e2k(keyword)
  },function(data){		
			if(data) {
			  $('#text_div').show();			  
			  $('#search_text').html('<ul><\/ul>');
			  $('#search_text > ul').html(decodeURIComponent(data));
			  $('.stext').mouseenter(function(){
				$(this).css({'background-color':'#eee'});
			  }).mouseleave(function(){
				$(this).css({'background-color':'#fff'});
			  }).mouseup(function(){
				$('#text_div').hide();
				$('input[name=findValue]').val($(this).text());
				db = $(this).text();		
				$("#searchForm").submit()
		      });
			}
  });
}

var e2k = (function() {
	var en_h = "rRseEfaqQtTdwWczxvg";
	var reg_h = "[" + en_h + "]";

	var en_b = {k:0,o:1,i:2,O:3,j:4,p:5,u:6,P:7,h:8,hk:9,ho:10,hl:11,y:12,n:13,nj:14,np:15,nl:16,b:17,m:18,ml:19,l:20};
	var reg_b = "hk|ho|hl|nj|np|nl|ml|k|o|i|O|j|p|u|P|h|y|n|b|m|l";

	var en_f = {"":0,r:1,R:2,rt:3,s:4,sw:5,sg:6,e:7,f:8,fr:9,fa:10,fq:11,ft:12,fx:13,fv:14,fg:15,a:16,q:17,qt:18,t:19,T:20,d:21,w:22,c:23,z:24,x:25,v:26,g:27};
	var reg_f = "rt|sw|sg|fr|fa|fq|ft|fx|fv|fg|qt|r|R|s|e|f|a|q|t|T|d|w|c|z|x|v|g|";

	var reg_exp = new RegExp("("+reg_h+")("+reg_b+")(("+reg_f+")(?=("+reg_h+")("+reg_b+"))|("+reg_f+"))","g");

	var replace = function(str,h,b,f) {
		return String.fromCharCode(en_h.indexOf(h) * 588 + en_b[b] * 28 + en_f[f] + 44032);
	};

	return (function(str) {
		return str.replace(reg_exp,replace);
	});
})();